fx_version 'adamant'
game 'gta5'


description 'os-policegarage'
version '2.2.0'
author 'Omega Scripts'


client_scripts {
    'client/main.lua',
    'client/menu.lua',
    'client/target.lua'
}

shared_script 'config.lua'
